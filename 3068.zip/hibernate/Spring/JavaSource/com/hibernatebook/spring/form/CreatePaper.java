package com.hibernatebook.spring.form;

public class CreatePaper {
	private String title;
	private String command;

	public String getTitle() {
		return title;
	}

	public String getCommand() {
		return command;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setCommand(String command) {
		this.command = command;
	}
}
