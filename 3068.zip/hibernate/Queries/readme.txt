Run the following tasks in order to carry out all of the operations and queries.

ant populate
ant SimpleHQL
ant CommentedHQL
ant FullyQualifiedHQL
ant ProjectionHQL
ant CriteriaForRestrictions
ant HQLForRestrictions
ant NamedParametersHQL
ant ObjectNamedParametersHQL
ant PagingHQL
ant UniqueResultHQL
ant OrderHQL
ant OrderTwoPropertiesHQL
ant AssociationsHQL
ant AssociationObjectsHQL
ant FetchAssociationsHQL
ant CountHQL
ant NamedQuery
ant ScalarSQL
ant SelectSQL
ant UpdateHQL
ant DeleteHQL

