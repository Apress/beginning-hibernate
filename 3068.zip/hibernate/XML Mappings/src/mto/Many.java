package mto;

public class Many {
	public int id;
	public One one;
}
