package mto;

public class TestManyToOne {
	public static void main(String[] args) {
		
	}
}
