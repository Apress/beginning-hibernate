package mto;

import java.util.Set;

public class One {
	public int id;
	public Set many;
}
