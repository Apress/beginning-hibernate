package sample;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import sample.dao.HibernateHelper;

public class TestChapter4 {
	   public static void main(String[] args) {	      
	      try {
	    	Session session = sessionFactory.openSession();

	    	session.beginTransaction();
	    	for(int i = 0; i < 100; i++) {
	    		session.save(new User("user:"+i,"test:"+i));
	    	}
	    	session.getTransaction().commit();
	    	session.close();
	    	
	    	session = sessionFactory.openSession();
	    	session.beginTransaction();
            int count = session.createQuery("from User").list().size();
            System.out.println(count + " users counted.");
            System.out.println("Deleting all the users...");
            session.createQuery("delete from User").executeUpdate();
	    	session.getTransaction().commit();
	    	session.close();
	    	
	    	session = sessionFactory.openSession();
	    	session.beginTransaction();
            count = session.createQuery("from User").list().size();
            System.out.println(count + " users counted after delete.");
	    	session.getTransaction().commit();
	    	session.close();
	      } catch (HibernateException e) {
	    	  e.printStackTrace();
	      }
	   }
	   
	   private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();	   
}
