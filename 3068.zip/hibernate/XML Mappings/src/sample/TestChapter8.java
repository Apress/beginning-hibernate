package sample;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import sample.dao.HibernateHelper;

public class TestChapter8 {
	   public static void main(String[] args) {
	      Transaction tx = HibernateHelper.getSession().beginTransaction();
	      try {
	    	Session session = HibernateHelper.getSession();

	    	User user = new User("dcminter","test1");

//	    	Phone phone1 = new Phone("555 123 1234","test1");
//	    	Phone phone2 = new Phone("555 123 1234","test2");
//
//	    	user.getPhoneNumbers().add(phone1);
//	    	user.getPhoneNumbers().add(phone2);
//
//	    	session.save(user);
//	    	session.save(phone1);
//	    	session.save(phone2);
	    	
	    	session.flush();

	    	session.refresh(user);
	    	
	    	System.out.println(user.getPhoneNumbers().size());
	    	
            tx.commit();
	      } catch (HibernateException e) {
	    	  e.printStackTrace();
	         tx.rollback();
	      }
	   }
}
