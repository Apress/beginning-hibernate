package sample;

import java.util.Iterator;
import java.util.List;

import sample.dao.CategoryDAO;
import sample.dao.DAO;
import sample.entity.Advert;
import sample.entity.Category;

public class ListAdverts {
   public static void main(String[] args) {
      try {
         List categories = new CategoryDAO().list();

         Iterator ci = categories.iterator();
         while(ci.hasNext()) {
            Category category = (Category)ci.next();
            System.out.println("Category: " + category.getTitle());
            System.out.println();
            Iterator ai = category.getAdverts().iterator();
            while(ai.hasNext()) {
               Advert advert = (Advert)ai.next();
               System.out.println();
               System.out.println("Title: " + advert.getTitle());
               System.out.println(advert.getMessage());
               System.out.println(" posted by " + advert.getUser().getName());
            }
         }
         
         DAO.close();
      } catch( AdException e ) {
         System.out.println(e.getMessage());
      }
   }   
}
