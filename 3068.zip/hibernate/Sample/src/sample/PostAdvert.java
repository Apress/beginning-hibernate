package sample;

import sample.dao.AdvertDAO;
import sample.dao.CategoryDAO;
import sample.dao.DAO;
import sample.dao.UserDAO;
import sample.entity.Advert;
import sample.entity.Category;
import sample.entity.User;

public class PostAdvert {
   public static void main(String[] args) {

      if (args.length != 4) {
         System.out.println("params required: username, categoryTitle, title, message");
         return;
      }

      String username = args[0];
      String categoryTitle = args[1];
      String title = args[2];
      String message = args[3];

      try {
         UserDAO users = new UserDAO();
         CategoryDAO categories = new CategoryDAO();
         AdvertDAO adverts = new AdvertDAO();

         User user = users.get(username);
         Category category = categories.get(categoryTitle);
         Advert advert = adverts.create(title, message, user);

         category.addAdvert(advert);
         categories.save(category);

         DAO.close();
      } catch (AdException e) {
         e.printStackTrace();
      }

   }
}
