package sample;

import sample.dao.CategoryDAO;
import sample.dao.DAO;

public class CreateCategory {
   public static void main(String[] args) {

      if (args.length != 1) {
         System.out.println("param required: categoryTitle");
         return;
      }

      CategoryDAO categories = new CategoryDAO();
      String title = args[0];
      try {
         System.out.println("Creating category " + title);
         categories.create(title);
         System.out.println("Created category");
         DAO.close();
      } catch (AdException e) {
         System.out.println(e.getMessage());
      }

   }

}
