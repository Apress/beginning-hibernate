package sample.entity.s5;

public class User {
   public int id;
   public String username;
}
