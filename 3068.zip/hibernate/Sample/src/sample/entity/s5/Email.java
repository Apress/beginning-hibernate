package sample.entity.s5;

public class Email {
   public int id;
   public String email;
}
