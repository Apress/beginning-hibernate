package sample.entity.lazy;

public class Email {
   public int id;
   public String email;
}
