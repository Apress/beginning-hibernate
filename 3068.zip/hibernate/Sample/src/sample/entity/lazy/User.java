package sample.entity.lazy;

public class User {
   public int id;
   public String username;
   public Email email;
}
