package sample.entity.lazy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class LazyTest {
   public static void main(String[] args)
      throws Exception
   {
      SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
      Session session = sessionFactory.openSession();
      session.beginTransaction();
      Email email = new Email();
      email.email = "dcminter@example.com";
      
      User user = new User();
      user.username = "dcminter";
      user.email = email;
      
      session.save(user);
      session.flush();
      session.getTransaction().commit();
      
      int id = user.id;

      System.out.println("Read");
      System.out.println(user.id);
      System.out.println(user.username);
      System.out.println(user.email);
      
      session.close();
      
      session = sessionFactory.openSession();
      User u2 = (User)session.get(User.class, new Integer(id));
      session.close();

      System.out.println("Re-read");
      System.out.println(u2);
      System.out.println(u2.id);
      System.out.println(u2.username);
      System.out.println(u2.email);

      
   }
}
