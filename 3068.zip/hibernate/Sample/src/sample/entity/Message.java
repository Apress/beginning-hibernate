package sample.entity;

public class Message {
	private String message;
	
	public Message(String message) {
		this.message = message;
	}

	Message() {
	}
	
	public String getMessage() {
		return this.message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
}
