package sample.entity.s2;

public class Email {
   public int id;
   public String username;
}
