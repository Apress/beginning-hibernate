package sample.entity.s2;

public class User {
   public int id;
   public String username;
   public Email email;
}
