package sample.entity.s4;

import java.util.Set;

public class Email {
   public int id;
   public String email;
   public Set users;
}
