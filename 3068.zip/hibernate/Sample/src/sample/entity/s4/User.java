package sample.entity.s4;


public class User {
   public int id;
   public String username;
   public Email email;
}
