package sample.entity.s3;

public class User {
   public int id;
   public String username;
   public Email email;
}
