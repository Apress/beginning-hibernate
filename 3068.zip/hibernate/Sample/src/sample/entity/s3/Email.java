package sample.entity.s3;

import java.util.Set;

public class Email {
   public int id;
   public String emails;
}
